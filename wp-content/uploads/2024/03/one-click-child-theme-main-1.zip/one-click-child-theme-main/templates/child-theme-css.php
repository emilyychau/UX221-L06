/*
Theme Name:     <?php echo $new_theme_title, "\n"; ?>
Description:    <?php echo $new_theme_description, "\n"; ?>
Author:         <?php echo $new_theme_author, "\n"; ?>
Template:       <?php echo $parent_theme_template, "\n"; ?>

(optional values you can add: Theme URI, Author URI, Version, License, License URI, Tags, Text Domain)
*/
